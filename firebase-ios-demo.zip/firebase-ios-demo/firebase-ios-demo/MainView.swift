//
//  MainView.swift
//  firebase-ios-demo
//
//

import SwiftUI

struct MainView: View {
    
        var body: some View {
            VStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                Text("Hello, world!")
            }
            .padding()
        }
}
